desertink.vim
=============

This is a version of the default desert colorscheme with a
darker background and more colorful foreground colors.

It also adds highlighting for folds, diffs, line numbers,
signcolumn, completion menus, and cursor line/column.

The colors are automatically converted for 88/256 color terminals,
adapted from http://www.vim.org/scripts/script.php?script_id=1243

You can find the latest version at https://github.com/toupeira/desertink.vim
and see a screenshot at http://i.imgur.com/DZ35F.png

![desertink](http://i.imgur.com/DZ35F.png)


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/toupeira/vim-desertink/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

